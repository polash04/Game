package com.game;

import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Game Play = new Game();
        Play.GamePlay();
    }
}
