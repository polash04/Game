package com.game;

abstract class Food
{
    abstract int get_price();
    abstract void set_quantity(int quantity);
    abstract int get_quantity();
}
